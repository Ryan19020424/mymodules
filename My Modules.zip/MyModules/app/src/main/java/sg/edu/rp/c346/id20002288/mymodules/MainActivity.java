package sg.edu.rp.c346.id20002288.mymodules;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TextView tvjava,tvsoft,tvit,tvbs,tvmobile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvjava=findViewById(R.id.tvjava);
        tvsoft=findViewById(R.id.tvsoft);
        tvit=findViewById(R.id.tvit);
        tvbs=findViewById(R.id.tvbs);
        tvmobile=findViewById(R.id.tvmobile);

        tvjava.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this,ModuleDetailActivity.class);
            intent.putExtra("java","Module code: C209\nModule Name: Advance Object Oriented Programming\nAcademic Year: 2021\nSemester: 1\nModule Credit: 4\nVenue: W65E");
            startActivity(intent);
            }
        });


        tvsoft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ModuleDetailActivity.class);
                intent.putExtra("software","Module code: C206\nModule Name: Software Development Process\nAcademic Year: 2021\nSemester: 1\nModule Credit: 4\nVenue: W67N");
                startActivity(intent);
            }
        });
        tvit.setOnClickListener(new View.OnClickListener() {
                                  @Override public void onClick(View v) {
                                      Intent intent = new Intent(MainActivity.this, ModuleDetailActivity.class);
                                      intent.putExtra("secuirty", "Module code: C235\nModule Name: IT Security and Management\nAcademic Year: 2021\nSemester:1\nModule Credit:4\nVenue:W65M");
                                      startActivity(intent);
                                  }
                              });


        tvbs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ModuleDetailActivity.class);
                intent.putExtra("busniess","Module code: C353\nModule Name: Business System\nAcademic Year: 2021\nSemester:1\nModule Credit:4\nVenue:W66R");
                startActivity(intent);
            }
        });

        tvmobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ModuleDetailActivity.class);
                intent.putExtra("mobileapp","Module code: C346\nModule Name: Mobile App Developement\nAcademic Year: 2021\nSemester:1\nModule Credit:4\nVenue:E62E");
                startActivity(intent);
            }
        });



    }
}