package sg.edu.rp.c346.id20002288.mymodules;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ModuleDetailActivity extends AppCompatActivity {
TextView tvdisplay;
Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_detail);
        tvdisplay=findViewById(R.id.tvdisplay);

        Intent ir = getIntent();
        String value = ir.getStringExtra("java");
        tvdisplay.setText(value);

        Intent ir1 = getIntent();
        String value1 = ir1.getStringExtra("software");
        tvdisplay.setText(value1);

        Intent ir2 = getIntent();
        String value2 = ir2.getStringExtra("security");
        tvdisplay.setText(value2);

        Intent ir3 = getIntent();
        String value3 = ir3.getStringExtra("business");
        tvdisplay.setText(value3);

        Intent ir4 = getIntent();
        String value4 = ir4.getStringExtra("mobileapp");
        tvdisplay.setText(value4);

        btn=findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
    }
}